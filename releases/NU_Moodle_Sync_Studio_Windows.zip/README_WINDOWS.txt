========================================================================
  Nile University Moodle Sync Studio — Windows Edition
  Made by : farisEmad
  For any bug or recommendation : WhatsApp 01020933516
========================================================================

1. Double-click 'NU_Moodle_Sync_Studio.exe'.
   (No Python or extra installation needed — everything is built in!)
2. Your browser will open http://127.0.0.1:8765 automatically.
3. Enter your Nile University Email and Password, click 'Select Folder (Table)'
   to pick where you want your courses saved, and click 'Connect & Scan My Courses'.

------------------------------------------------------------------------
  Made by : farisEmad | WhatsApp : 01020933516
========================================================================
